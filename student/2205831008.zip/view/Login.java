package student.view;

import student.modle.openStudentFrame;

public class Login {
    public static void main(String[] args) {
        openStudentFrame loginFrame = new openStudentFrame();
        loginFrame.setVisible(true);
    }
}
